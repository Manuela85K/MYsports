package com.sportsapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.sportsapp.R

class MainActivity : AppCompatActivity() {
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bottomNavigationView = findViewById(R.id.bottom)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.title = getString(R.string.first_fragment_title)
        // Initialize the first fragment
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, MySports())
            .commit()

        // Set listener for bottom navigation clicks
        bottomNavigationView.setOnNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.mysports -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, MySports())
                        .commit()
                    toolbar.title = getString(R.string.first_fragment_title)
                    true
                }
                R.id.account -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, Account())
                        .commit()
                    toolbar.title = getString(R.string.second_fragment_title)
                    true
                }
                R.id.SportsList -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, ListSports())
                        .commit()
                    toolbar.title = getString(R.string.third_fragment_title)
                    true
                }
                else -> false
            }
        }

    }

}